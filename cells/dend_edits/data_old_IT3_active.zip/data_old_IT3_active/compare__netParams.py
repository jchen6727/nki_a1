### CHANGE 3 THINGS
from netpyne import specs, sim

try:
	from __main__ import cfg  # import SimConfig object with params from parent module
except:
	from cfg import cfg  # if no simConfig in parent module, import directly from tut8_cfg module


netParams = specs.NetParams() 
netParams.popParams['TestPop'] = {'cellType': 'IT', 'numCells': 1, 'cellModel': 'HH_reduced'} # (1) #cellType

cellRule = netParams.loadCellParamsRule(label='IT2_reduced', fileName='IT2_reduced_cellParams.pkl') # (2) & (3) #cellName

## Add in Stimulation Source (IClamp) 
netParams.stimSourceParams['Input'] = {'type': 'IClamp', 'del': 250, 'dur': 1000, 'amp': cfg.amp} 
netParams.stimTargetParams['Input->TestPop'] = {'source': 'Input', 'sec':'soma', 'loc': 0.5, 'conds': {'pop':'TestPop'}}
